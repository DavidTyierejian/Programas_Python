class Crear:
    def crear(self):
        self.nombre = input("Ingrese el nombre del archivo que quiere crear, debe incluir el tipo de archivo:\n")
        self.archivo = open(self.nombre, "w")
        self.archivo.close()