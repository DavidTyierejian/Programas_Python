import os
class Eliminar:
    def eliminar(self):
        self.nombre_archivo = input("Ingrese el nombre del archivo que quiere eliminar, debe incluir el tipo de archivo:\n")
        if os.path.exists(self.nombre_archivo):
            print("Archivo eliminado")
            os.remove(self.nombre_archivo)
        else:
            print("El archivo no existe, intente otra vez.\n")
