from Crear import Crear
from Modificar import Modificar
from Eliminar import Eliminar

start = 0
print("¡Hola! ¿Qué quiere hacer hoy?")
while start != 4:

    #Input del usuario para elegir opciones
    try: start = int(input("Seleccione una opción:\n1: Crear archivo\n2: Modificar archivo\n3: Eliminar archivo\n4: Cerrar programa\n"))
    except ValueError:
        print("Caracter invalido, seleccione una opción correcta")

    #IF Clase Crear
    if start == 1:
        archivo = Crear()
        archivo.crear()
        print("Archivo creado")

    #IF Clase Modificar
    elif start == 2:
        archivo = Modificar()
        archivo.modificar()

    #IF Clase Eliminar
    elif start == 3:
        archivo = Eliminar()
        archivo.eliminar()

    #Cerrar programa
    elif start == 4:
        break

print("Programa cerrado")