import os
class Modificar:
    def modificar(self):
        accion = 0
        while accion != 4:
            #Input de opciones

            try: accion = int(input("1: Añadir una línea al final del texto\n2: Borrar una línea del archivo"
                                 "\n3: Modificar una línea del texto\n4: Volver atrás\n"))
            except ValueError:
                print("Caracter inválido, seleccione una opción correcta")

            #Crear linea en archivo

            if accion == 1:
                #input del archivo

                self.nombre_archivo = input("Ingrese el nombre del archivo que quiere modificar, "
                                                "debe incluir la extensión:\n")
                if os.path.exists(self.nombre_archivo):
                    self.archivo = open(self.nombre_archivo, "a")

                    # input del texto para añadir
                    self.texto = input("Ingrese texto que va a añadir al archivo:\n")
                    self.archivo.write("\n" + self.texto)
                    self.archivo.close()
                else:
                    print("El archivo no existe, vuelva a intentar\n")

            # Eliminar linea de archivo

            elif accion == 2:
                # input del archivo

                self.nombre_archivo = input("Ingrese el nombre del archivo que quiere modificar, "
                                                "debe incluir la extensión:\n")

                if os.path.exists(self.nombre_archivo):
                    self.archivo = open(self.nombre_archivo, "r")
                    self.lineas = self.archivo.readlines()
                    self.archivo.close()

                    # Input para elegir linea que se borrara

                    self.linea = int(input("¿Qué línea quiere borrar?:\n"))

                    # Como borra la linea

                    del self.lineas[self.linea]
                    self.nuevo_archivo = open(self.nombre_archivo, "w+")
                    for linea in self.lineas:
                        self.nuevo_archivo.write(linea)
                    self.nuevo_archivo.close()
                else:
                    print("El archivo no existe, vuelva a intentar\n")

            # Modificar linea de archivo

            elif accion == 3:
                # input del archivo

                self.nombre_archivo = input("Ingrese el nombre del archivo que quiere modificar, "
                                                "debe incluir el tipo:\n")
                if os.path.exists(self.nombre_archivo):
                    self.archivo = open(self.nombre_archivo, "r")
                    self.lista_de_lineas = self.archivo.readlines()

                    # Input de linea por modificar

                    self.linea = int(input("¿Qué línea quiere modificar?:\n"))

                    # Modificacion de texto en la linea
                    if len(self.linea) == self.linea:
                        self.texto = input("Ingrese el texto para la línea modificada:\n")
                        self.lista_de_lineas[self.linea] = self.texto
                        self.archivo = open(self.nombre_archivo, "w")
                        self.lista_de_lineas[self.linea] = self.texto + "\n"
                        self.archivo.writelines(self.lista_de_lineas)
                        self.archivo.close()
                    else:
                        print("Linea fuera de rango, intente otra vez")
                else:
                    print("El archivo no existe, vuelva a intentar\n")

            #Cerrar programa
            elif accion == 4:
                break

