class horas_Extras():
    def calcular_Horas_Extras(self):
        opcion = 0
        while opcion != 2:
            # Variables e inputs de usuario
            try:
                self.sueldo_bruto = float(input("Ingrese su sueldo bruto:\n"))
                self.horas_trabajadas = int(input("Ingrese horas trabajadas:\n"))
                self.dias_trabajados = int(input("Ingrese días trabajados:\n"))

                self.pago_extra_semana = 1.5
                self.pago_extra_finde = 2.0

                self.horas_extras_semana = int(input("Ingrese sus horas extras en la semana:\n"))
                self.horas_extras_finde = int(input("Ingrese sus horas extras de fin de semana:\n"))

                # Calcular horas trabajadas
                self.sueldo_horas_trabajadas = (self.sueldo_bruto / self.dias_trabajados) \
                                               / self.horas_trabajadas

                self.sueldo_horas_extras_semana = self.sueldo_horas_trabajadas * \
                                                  self.pago_extra_semana * self.horas_extras_semana

                self.sueldo_horas_extras_finde = self.sueldo_horas_trabajadas \
                                                 * self.pago_extra_finde * self.horas_extras_finde

                print("Su sueldo por hora es " + "$" + str(self.sueldo_horas_trabajadas) + "ARS")
                print("Su sueldo por hora extra es " + "$" + str(self.sueldo_horas_extras_semana) + "ARS")
                print("Su sueldo por hora extra en fin de semana es: " + "$" +
                      str(self.sueldo_horas_extras_finde) + "ARS")

                # Input de usuario, try except en caso de error
                try:
                    opcion = int(input("¿Seguir calculando horas trabajadas o volver atrás?:"
                                   "\n1: Calcular horas extras\n2: Volver atrás\n"))
                except ValueError:
                    print("Opción inválida, vuelva a intentar:\n")
                    opcion = int(input("1: Intentar de nuevo\n2: Volver atrás\n"))

            # Except en caso de valor erróneo
            except ValueError:
                try:
                    opcion = int(input("Valor inválido. ¿Intentar de nuevo, o volver atras?\n"
                                       "1: Intentar de nuevo\n"
                                       "2: Volver atras\n"))
                except ValueError:
                    print("Opción inválida, ingrese una opción correcta:\n")
                    opcion = int(input("1: Intentar de nuevo\n2: Volver atrás\n"))
