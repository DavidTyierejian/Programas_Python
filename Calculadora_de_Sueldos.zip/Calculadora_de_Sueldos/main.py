from Sueldo_Neto import sueldo_Neto
from Horas_Trabajadas import sueldo_Horas_Trabajadas
from horas_Extras import horas_Extras

opcion = 0
print("¡Hola! ¿Qué va a querer hacer hoy?")
while opcion != 4:

    # Try y except en caso de valor erróneo
    try:
        opcion = int(input("1: Calcular sueldo neto\n2: Calcular horas trabajadas\n3: "
                           "Calcular horas extras\n4: Cerrar programa\n"))
    except ValueError:
        print("Opción inválida, ingrese un valor correcto:\n")

    # Opcion calcular sueldo neto
    if opcion == 1:
        sueldo_neto = sueldo_Neto()
        sueldo_neto.calcular_sueldo_neto()

    # Opcion calcular horas trabajadas
    if opcion == 2:
        horas_trabajadas = sueldo_Horas_Trabajadas()
        horas_trabajadas.calcular_horas_trabajadas()

    # Opcion calcular horas extras
    if opcion == 3:
        horas_extras_trabajadas = horas_Extras()
        horas_extras_trabajadas.calcular_Horas_Extras()

    # Finalizar programa
    if opcion == 4:
        break

print("Programa cerrado")
