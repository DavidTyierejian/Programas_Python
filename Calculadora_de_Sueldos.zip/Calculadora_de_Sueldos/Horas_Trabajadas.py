class sueldo_Horas_Trabajadas:
    def calcular_horas_trabajadas(self):
        opcion = 0
        while opcion != 2:

            # Variables e inputs de usuario
            try:
                self.sueldo_bruto = float(input("Ingrese su sueldo bruto:\n"))
                self.horas_trabajadas = int(input("Ingrese horas trabajadas:\n"))
                self.dias_trabajados = int(input("Ingrese días trabajados:\n"))

                # Calcular horas trabajadas
                self.sueldo_horas_trabajadas = (self.sueldo_bruto / self.dias_trabajados) / self.horas_trabajadas

                print("Su sueldo por hora es: " + "$" + str(self.sueldo_horas_trabajadas) + "ARS")

                # Input de usuario, try except en caso de error
                try:
                    opcion = int(input("¿Seguir calculando horas trabajadas o volver atrás?:"
                                       "\n1: Calcular horas\n2: Volver atrás\n"))
                except ValueError:
                    print("Opción inválida, vuelva a intentar:\n")
                    opcion = int(input("1: Intentar de nuevo\n2: Volver atrás\n"))

            # Except en caso de valor erróneo en el input

            except ValueError:
                try: opcion = int(input("Valor inválido. ¿Intentar de nuevo, o volver atras?\n1: Intentar de nuevo\n"
                                        "2: Volver atras\n"))
                except ValueError:
                    print("Opción inválida, ingrese una opción correcta:\n")
                    opcion = int(input("1: Intentar de nuevo\n2: Volver atrás\n"))