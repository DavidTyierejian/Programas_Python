class sueldo_Neto:
    def calcular_sueldo_neto(self):
        opcion = 0
        while opcion != 2:

            # Variables e input de usuario
            try:
                self.sueldo_bruto = float(input("Ingrese su sueldo en bruto:\n"))
                self.jubilacion = 0.11
                self.obra_social = 0.03
                self.PAMI = 0.03

                # Calcular sueldo Neto
                self.sueldo_neto = self.sueldo_bruto - (self.sueldo_bruto * self.jubilacion) - \
                                   (self.sueldo_bruto * self.obra_social) - (self.sueldo_bruto * self.PAMI)

                print("Su sueldo neto es " + "$" + str(self.sueldo_neto) + " ARS")

                # input de usuario, y try except en caso de error
                try: opcion = int(input("¿Seguir calculando sueldos o volver atrás?:"
                                            "\n1: Calcular sueldo\n2: Volver atrás\n"))
                except ValueError:
                    print("Opción inválida, vuelva a intentar:\n")
                    opcion = int(input("1: Intentar de nuevo\n2: Volver atrás\n"))

            # Except en caso de valor erróneo
            except ValueError:
                try: opcion = int(input("Valor inválido. ¿Intentar de nuevo, "
                                        "o volver atras?\n1: Intentar de nuevo\n"
                                       "2: Volver atras\n"))
                except ValueError:
                    print("Opción inválida, ingrese una opción correcta:\n")
                    opcion = int(input("1: Intentar de nuevo\n2: Volver atrás\n"))